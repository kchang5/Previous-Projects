#include "IntList.h"

void IntList::distanceFrom(int key) {
   
}


int IntList::searchAndModify(IntNode *curr, int key) {
   return 0;
}

