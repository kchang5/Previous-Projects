#include "minFunc.h"
const int * min(const int arr[], int arrSize) {

}